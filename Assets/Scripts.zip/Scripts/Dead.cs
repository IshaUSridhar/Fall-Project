using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dead : MonoBehaviour
{
    public GameObject deadMenu;
    public Life targetLife;

    // Start is called before the first frame update
    void Start()
    {
        deadMenu.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (targetLife.amount == 0)
        {
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
            deadMenu.SetActive(true);
            Time.timeScale = 0;
        }
    }
}
