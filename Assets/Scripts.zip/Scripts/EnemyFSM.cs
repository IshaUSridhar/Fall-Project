using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyFSM : MonoBehaviour
{
    public enum EnemyState { ChasePlayer, AttackPlayer }

    public EnemyState currentState;
    public Sight sightSensor;
    public float playerAttackDistance;
    private NavMeshAgent agent;
    public float lastShootTime;
    public GameObject bulletPrefab;
    public float fireRate;
    Animator animator;

    // Start is called before the first frame update
    void Awake()
    {
        agent = GetComponentInParent<NavMeshAgent>();
        animator = GetComponentInParent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (currentState == EnemyState.ChasePlayer) { ChasePlayer(); }
        else { AttackPlayer(); }
    }

    void ChasePlayer() 
    {
        animator.SetBool("Shooting", false);
        agent.isStopped = false;

        print("ChasePlayer"); 
        if (sightSensor.detectedObject == null)
        {
            //Put idle animation here
            return;
        }

        agent.SetDestination(sightSensor.detectedObject.transform.position);

        float distanceToPlayer = Vector3.Distance(transform.position,
            sightSensor.detectedObject.transform.position);

        if (distanceToPlayer <= playerAttackDistance)
        {
            currentState = EnemyState.AttackPlayer;
        }
    }
    void AttackPlayer() 
    {
        agent.isStopped = true;

        print("AttackPlayer"); 
        if (sightSensor.detectedObject == null)
        {
            //Put idle animation here
            return;
        }

        LookTo(sightSensor.detectedObject.transform.position);
        Shoot();

        float distanceToPlayer = Vector3.Distance(transform.position,
            sightSensor.detectedObject.transform.position);

        if (distanceToPlayer > playerAttackDistance * 2.2f)
        {
            currentState = EnemyState.ChasePlayer;
        }
    }

    void LookTo(Vector3 targetPosition)
    {
        Vector3 directionToPosition = Vector3.Normalize(
            targetPosition - transform.parent.position);
        directionToPosition.y = 0;
        transform.parent.forward = directionToPosition;
    }

    void Shoot()
    {
        var timeSinceLastShoot = Time.time - lastShootTime;
        animator.SetBool("Shooting", true);
        if (timeSinceLastShoot > fireRate && Time.timeScale > 0)
        {
            lastShootTime = Time.time;
            Instantiate(bulletPrefab,
                transform.position, transform.rotation);
        }
    }

    private void OnDrawGizmos()
    {
        //Gizmos.color = Color.yellow;
        //Gizmos.DrawWireSphere(transform.position, playerAttackDistance);
    }
}
